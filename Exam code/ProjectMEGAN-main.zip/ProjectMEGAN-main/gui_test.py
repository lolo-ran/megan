from GUI import GUI
import time


# Example usage:
gui = GUI()

time.sleep(1)

gui.read_audio(f"./audio_samples/ORANGE.mp3")